## intent:flight
-hey! I want latest flight schedule
-can you provide me flight schedule
-please provide latest flight info
-is it possible to get latest flight information
-flight schedule
-flight information
-flight info


## intent:inform
-[DEL](location)
-[BOM](location)
-[CCU](location)
-[BLR](location)
-[HYD](location)
-[MAA](location)
-[PNQ](location)
-[IXC](location)
-[09-01-2019](date)
- I want for [09-02-2019](date)
- i want to travel on [21-04-2019](date)


## intent:affirmation
-ok
-yea
-yes
-definitely
-yah

## intent:deny
-no
-not yet
-never
-not now
